package cn.edu.xjtlu.HAOYUHE.myshop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.youth.banner.Banner;
import com.youth.banner.adapter.BannerAdapter;
import com.youth.banner.indicator.CircleIndicator;

import java.util.Arrays;
import java.util.List;

public class ImageBannerActivity extends AppCompatActivity {
    private List<Integer>images= Arrays.asList(
            R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3,
            R.drawable.image4,
            R.drawable.image5
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_banner);


        Banner banner=findViewById(R.id.banner);

        banner.setIndicator(new CircleIndicator(this));

        banner.setAdapter(new ImageBannerAdapter(images));
    }
}
class ImageBannerAdapter extends BannerAdapter<Integer,ImageViewHolder>{


    public ImageBannerAdapter(List<Integer> datas) {
        super(datas);
    }

    @Override
    public ImageViewHolder onCreateHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.image_banner_item,parent,false);
        return new ImageViewHolder(itemView);
    }

    @Override
    public void onBindView(ImageViewHolder holder, Integer data, int position, int size) {
    holder.imageView.setImageResource(data);
    }
}
class ImageViewHolder extends RecyclerView.ViewHolder{
     ImageView imageView;
    public ImageViewHolder(@NonNull View itemView) {
        super(itemView);
        imageView= (ImageView) itemView;
    }
}
