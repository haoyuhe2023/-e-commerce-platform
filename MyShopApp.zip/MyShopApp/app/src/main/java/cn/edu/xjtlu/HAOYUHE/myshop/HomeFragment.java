package cn.edu.xjtlu.HAOYUHE.myshop;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.youth.banner.Banner;
import com.youth.banner.adapter.BannerAdapter;
import com.youth.banner.indicator.CircleIndicator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class HomeFragment extends Fragment {
    private Banner banner;
    private GridView gridView;
    private GridView gridView2;
    private RadioButton message;

    private List<Map<String,Object>>dataList2;
    private List<Map<String,Object>>dataList;

    private int[]image_recommend={R.drawable.recommend01,R.drawable.recommend02,R.drawable.recommend03,
    R.drawable.recommend04,R.drawable.recommend05,R.drawable.recommend06};

    private String[] name={"【我要淘】魔幻" + "包包（八成新）","【我要淘】新款包包（九成新）","【我要淘】日常萌系小恶魔（...)",
            "预售新品全新拼盘（九成新）","绝美风格搭配（八成新）","微微一笑很倾城"};



    private int[] icon = {R.drawable.menu_cycy, R.drawable.menu_cosplay, R.drawable.menu_carttoon, R.drawable.menu_model, R.drawable.menu_stationery,
             R.drawable.menu_jewelry, R.drawable.menu_game, R.drawable.menu_oldage, R.drawable.menu_snack,R.drawable.menu_more};
    private String[] iconName = { "秋款", "夹克", "卫衣", "西装", "风衣",
            "皮衣", "纯色", "长裤", "衬衫", "更多" };
    private SimpleAdapter IconAdapter;
    private SimpleAdapter IconAdapter2;

    private List<Integer> images = Arrays.asList(
            R.drawable.image2,
            R.drawable.image3,
            R.drawable.image9,
            R.drawable.image4,
            R.drawable.image10
    );



    public HomeFragment() {
        // Required empty public constructor
    }





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view= LayoutInflater.from(getActivity()).inflate(R.layout.fragment_home, container, false);
        banner=view.findViewById(R.id.banner_home);

        banner.setIndicator(new CircleIndicator(getContext()));

        banner.setAdapter(new cn.edu.xjtlu.HAOYUHE.myshop.ImageBannerAdapter(images));

        dataList=new ArrayList<Map<String, Object>>();
        getData();

        dataList2=new ArrayList<Map<String,Object>>();
        getData2();

        String [] from1 ={"image","text"};
        int [] to1 = {R.id.image_icon,R.id.image_text};
        IconAdapter = new SimpleAdapter(getContext(), dataList, R.layout.item_icon, from1, to1);

        String [] from2={"image2","text2"};
        int[]to2={R.id.image_re,R.id.image_re_text};
        IconAdapter2=new SimpleAdapter(getContext(),dataList2,R.layout.item_recommend,from2,to2);



        gridView=view.findViewById(R.id.gridview);

        gridView2=view.findViewById(R.id.gridview2);
        gridView2.setAdapter(IconAdapter2);
        gridView.setAdapter(IconAdapter);

        return view;
    }

    public List<Map<String, Object>> getData(){

        for(int i=0;i<icon.length;i++){
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("image", icon[i]);
            map.put("text", iconName[i]);
            dataList.add(map);
        }

        return dataList;
    }
    public List<Map<String, Object>> getData2(){

        for(int i=0;i<image_recommend.length;i++){
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("image2", image_recommend[i]);
            map.put("text2", name[i]);
            dataList2.add(map);
        }
        return dataList2;
    }







    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        message = getActivity().findViewById(R.id.message);
        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "进入消息中心", Toast.LENGTH_LONG).show();
            }
        });
    }
    class ImageBannerAdapter extends BannerAdapter<Integer, cn.edu.xjtlu.HAOYUHE.myshop.ImageViewHolder> {


        public ImageBannerAdapter(List<Integer> datas) {
            super(datas);
        }








        @Override
        public cn.edu.xjtlu.HAOYUHE.myshop.ImageViewHolder onCreateHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.image_banner_item,parent,false);
            return new cn.edu.xjtlu.HAOYUHE.myshop.ImageViewHolder(itemView);
        }

        @Override
        public void onBindView(cn.edu.xjtlu.HAOYUHE.myshop.ImageViewHolder holder, Integer data, int position, int size) {
            holder.imageView.setImageResource(data);
        }
    }
    class ImageViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView= (ImageView) itemView;
        }
    }



}