package cn.edu.xjtlu.HAOYUHE.myshop.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.widget.RadioGroup;

import cn.edu.xjtlu.HAOYUHE.myshop.CartFragment;
import cn.edu.xjtlu.HAOYUHE.myshop.CategoryFragment;
import cn.edu.xjtlu.HAOYUHE.myshop.HomeFragment;
import cn.edu.xjtlu.HAOYUHE.myshop.R;
import cn.edu.xjtlu.HAOYUHE.myshop.RecommendFragment;
import cn.edu.xjtlu.HAOYUHE.myshop.SettingFragment;

public class MainActivity extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            RadioGroup radioGroupNav= findViewById(R.id.radioGroup_nav);
            radioGroupNav.setOnCheckedChangeListener(this::bottomNavButtonCheckedChanged);
            radioGroupNav.check(R.id.radioButton_homepage);
        }



        private void bottomNavButtonCheckedChanged(RadioGroup group, int checkedId){
            Class<? extends Fragment> fragmentClass=null;

            if(checkedId==R.id.radioButton_homepage) {
                fragmentClass = HomeFragment.class;

            }else if (checkedId==R.id.type){
                fragmentClass= CategoryFragment.class;

            }else if(checkedId==R.id.daily_recommend){
                fragmentClass= RecommendFragment.class;

            }else if(checkedId==R.id.cart){
                fragmentClass= CartFragment.class;

            }else{
                fragmentClass= SettingFragment.class;
            }

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container,fragmentClass,null)
                    .setReorderingAllowed(true)
                    .commit();

        }
    }
